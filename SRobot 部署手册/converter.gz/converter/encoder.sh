#!/bin/bash
# File: converter.sh
# Date: August 19th, 2016
# Time: 18:56:52 +0800
# Author: kn007 <kn007@126.com>
# Blog: https://kn007.net
# Link: https://github.com/kn007/silk-v3-encoder
# 
# Usage: sh converter.sh silk_v3_file/input_folder output_format/output_folder flag(format)
# Flag: not define   ----  not define, convert a file
#       other value  ----  format, convert a folder, batch conversion support
# Requirement: gcc ffmpeg

# Colors
RED="$(tput setaf 1 2>/dev/null || echo '\e[0;31m')"
GREEN="$(tput setaf 2 2>/dev/null || echo '\e[0;32m')"
YELLOW="$(tput setaf 3 2>/dev/null || echo '\e[0;33m')"
WHITE="$(tput setaf 7 2>/dev/null || echo '\e[0;37m')"
RESET="$(tput sgr 0 2>/dev/null || echo '\e[0m')"

# Main
cur_dir=$(cd `dirname $0`; pwd)

if [ ! -r "$cur_dir/silk/encoder" ]; then
	echo -e "${WHITE}[Notice]${RESET} Silk v3 Encoder is not found, compile it."
	cd $cur_dir/silk
	make && make encoder
	[ ! -r "$cur_dir/silk/encoder" ]&&echo -e "${RED}[Error]${RESET} Silk v3 Encoder Compile False, Please Check Your System For GCC."&&exit
	echo -e "${WHITE}========= Silk v3 Encoder Compile Finish =========${RESET}"
fi

cd $cur_dir

#转换文件
ffmpeg -i "$1" -f s16le -acodec pcm_s16le  -ar 24000  "$1.pcm"
$cur_dir/silk/encoder "$1.pcm" "${1%.*}.amr" -tencent > /dev/null 2>&1
rm "$1.pcm"
exit
