#!/bin/bash
mysqldump -uroot -pQiadao123 srobot > /home/backup/log/srobot_$(date +%Y%m%d_%H%M%S).sql

